#pragma once

#include <string>

std::wstring toWstring(std::string source);
