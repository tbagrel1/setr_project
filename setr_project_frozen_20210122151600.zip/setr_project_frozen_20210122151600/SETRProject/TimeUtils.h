#pragma once

uint64_t timestampNow();
Platform::String^ timestampToString(uint64_t timestamp);