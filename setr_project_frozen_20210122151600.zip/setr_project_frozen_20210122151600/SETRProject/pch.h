﻿//
// pch.h
//

#pragma once

#include <collection.h>
#include <ppltasks.h>

#include "App.xaml.h"
